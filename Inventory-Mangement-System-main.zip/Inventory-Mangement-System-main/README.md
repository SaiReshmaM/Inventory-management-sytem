# Inventory-Mangement-System
Inventory Management System using MERN Stack.
The inventory management system is developed to help companies manage their inventories online. 
It utilizes technologies such as React, Node, MongoDB, Express, and Redux to provide a seamless experience 
for businesses looking to streamline their inventory management processes.
