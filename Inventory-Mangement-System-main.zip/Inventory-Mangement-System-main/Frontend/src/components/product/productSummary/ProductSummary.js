import React from 'react'

const ProductSummary = () => {
  return (
    <div>ProductSummary</div>
  )
}

export default ProductSummary